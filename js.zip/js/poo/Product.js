// Product Constructor
export class Product {
    constructor(name, puntos, year) {
        this.name = name;
        this.puntos = puntos;
        this.year = year;
    }
}