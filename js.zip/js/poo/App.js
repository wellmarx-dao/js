import { Product } from "./Product.js";
import { UI } from "./UI.js";

// DOM Eventos
document
  .getElementById("product-form")
  .addEventListener("submit", function (e) {
    // Anular el comportamiento de formulario predeterminado
    e.preventDefault();

    // Obtener valores de formulario
    const name = document.getElementById("name").value,
    puntos = document.getElementById("puntos").value,
      year = document.getElementById("year").value;

    // Crear un nuevo producto Oject
    const product = new Product(name, puntos, year);

    // Crea una nueva instancia de IU
    const ui = new UI();

    // Validación de usuario de entrada
    if (name === "" || puntos === "" || year === "") {
      ui.showMessage("favor insertar datos", "danger");
    }

    // guardar Product
    ui.addProduct(product);
    ui.showMessage("Pelicula adicionada", "success");
    ui.resetForm();
  });

document.getElementById("product-list").addEventListener("click", (e) => {
  const ui = new UI();
  ui.deleteProduct(e.target);
  e.preventDefault();
});
