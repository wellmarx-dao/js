function ejercicio_1() {
    var costo=Number(document.getElementById('costo').value);
    var cantidad=Number(document.getElementById('cantidad').value);
    var total=costo*cantidad;

    document.getElementById('total').value=total;
}

function ejercicio_2() {
    var num1=Number(document.getElementById('num1').value);
    var num2=Number(document.getElementById('num2').value);
    var suma = num1+num2;
    var rest = num1-num2;
    var mult = num1*num2;
    var divi = num1/num2;

    document.getElementById('suma').value=suma;
    document.getElementById('rest').value=rest;
    document.getElementById('mult').value=mult;
    document.getElementById('divi').value=divi;
}

function ejercicio_3() {
    var salario = Number(document.getElementById('salario').value);
    var salud = salario*0.09;
    var psion = salario*0.12;

    document.getElementById('salud').value=salud;
    document.getElementById('psion').value=psion;
}

function ejercicio_4() {
    var vusd = Number(document.getElementById('vusd').value);
    var tasa = 3739;
    var vcop = vusd*tasa;

    document.getElementById('vcop').value=vcop;
}

function ejercicio_5() {
    var vcop = Number(document.getElementById('vcop').value);
    var tasa = 4564;
    var veur = vcop/tasa;

    document.getElementById('veur').value=veur;
}


function ejercicio_6() {
    var monto = Number(document.getElementById('monto').value);
    var meses = Number(document.getElementById('meses').value);
    var interes = 0.09;
    var formula = ( interes * monto )/(( 1 - ( 1 + interes ) ** ( -1 * meses )));
    var cuota = Math.round(formula);

    document.getElementById('cuota').value=cuota;
}

function ejercicio_7() {
    var nota1 = Number(document.getElementById('nota1').value);
    var nota2 = Number(document.getElementById('nota2').value);
    var nota3 = Number(document.getElementById('nota3').value);

    promedio = (nota1+nota2+nota3)/3;

    document.getElementById('promedio').value=promedio;
}

function ejercicio_8() {
    var horas = Number(document.getElementById('horas').value);
    var salarihora = 33000;
    var transporte = 11111;

    salario = (salarihora * horas) + transporte;

    document.getElementById('salario').value=salario;
}

function ejercicio_09() {
    var edad_año = Number(document.getElementById('edad_año').value);
    var prom_edad = 80;
    var edad_mes = edad_año*12;
    var vida_rest = prom_edad - edad_año;

    document.getElementById('edad_mes').value=edad_mes;
    document.getElementById('vida_rest').value=vida_rest;
}


function ejercicio_10() {
    var ahorro_mes = Number(document.getElementById('ahorro_mes').value);
    var interes = 0.29;
    var ahorro_año = (( ahorro_mes * interes) + ahorro_mes ) * 12;

    document.getElementById('ahorro_año').value=ahorro_año;
}

function ejercicio_11() {
    var nota1 = Number(document.getElementById('nota1').value);
    var nota2 = Number(document.getElementById('nota2').value);
    var nota3 = Number(document.getElementById('nota3').value);
    var nota4 = Number(document.getElementById('nota4').value);

    var promedio = (nota1+nota2+nota3+nota4)/4;

    if (promedio >= 3) {
        document.getElementById('promedio').value='APROBADO';
    } else {
        document.getElementById('promedio').value='DESAPROBADO';
    }
}

function ejercicio_12() {
    var salario = Number(document.getElementById('salario').value);
    var tope = 2500000;
    var subt = 0.07;

    if (salario >= tope) {
        salario_total = salario;
        document.getElementById('salario_total').value='No tiene subsidio de transporte';

    } else {
        salario_total = (salario*subt) + salario;
        document.getElementById('salario_total').value=salario_total;
    }
}

function ejercicio_13() {
    var edad = Number(document.getElementById('edad').value);

    if (edad >= 18) {
        rango_edad = edad;
        document.getElementById('rango_edad').value='Usted es mayor de edad';

    } else {
        rango_edad = edad;
        document.getElementById('rango_edad').value='Usted es menor de edad';
    }
}

function ejercicio_14() {
    var salario = Number(document.getElementById('salario').value);
    var tope = 2000000;
    var sinav = 0.09;
    var nonav = 0.05;

    if (salario >= tope) {
        salario_nav = (salario * sinav) + salario;
        document.getElementById('salario_nav').value=salario_nav;
    } else {
        salario_nav = (salario * nonav) + salario;
        document.getElementById('salario_nav').value=salario_nav;
    }
}

function ejercicio_15() {
    var monto = Number(document.getElementById('monto').value);
    var meses = Number(document.getElementById('meses').value);

    if (meses <= 3){
        var int_total = (monto * 0.03) * meses;
        document.getElementById('int_total').value=int_total;
    } else {
        var int_total = (monto * 0.09) * meses;
        document.getElementById('int_total').value=int_total;
    } 
}

function ejercicio_16() {
    var costo = Number(document.getElementById('costo').value);
    var cantd = Number(document.getElementById('cantd').value);
    var total = costo * cantd;

    if ( total >= 60000){
        var pagar = total - (total * 0.03);
        document.getElementById('pagar').value=pagar;

    } else {
        var pagar = total;
        document.getElementById('pagar').value=pagar;
    } 
}

function ejercicio_17() {
    var edad = Number(document.getElementById('edad').value);

    if ( edad >= 70){
        vacuna = edad;
        document.getElementById('vacuna').value='Puede ser vacunado en centros de salud';

    } else {
        vacuna = edad;
        document.getElementById('vacuna').value='Debe esperar la etapa de vacunación para su rango de edad';

    } 
}





   
    
   